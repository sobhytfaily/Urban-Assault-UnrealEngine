#pragma once
UENUM(BlueprintType)
enum class ECombatState : uint8
{
	ECS_Unoccupied UMETA(DisplayName ="Unoccupied"),
	ECS_Reloading UMETA(DisplayName = "Reloading"),
	ECS_ThrowingGernade UMETA(DisplayName = "ThrowingGernade"),
	ECS_SwapingWeapons UMETA(DisplayName = "SwapingWeapons"),
	ECS_MAX UMETA(DisplayName = "DefualtMAX")
};