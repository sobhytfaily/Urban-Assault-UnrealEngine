// Fill out your copyright notice in the Description page of Project Settings.


#include "InteractWithCrosshairInterface.h"

// Add default functionality here for any IInteractWithCrosshairInterface functions that are not pure virtual.
